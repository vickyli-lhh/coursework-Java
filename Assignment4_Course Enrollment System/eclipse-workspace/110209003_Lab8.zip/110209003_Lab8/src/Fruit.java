
public class Fruit {
	private String name;
	private int cost;
	private int price;
	
	public Fruit(String name, int cost, int price) {
		this.name = name;
		this.cost = cost;
		this.price = price;
	}
	
	public int getCost() {
		return cost;
	}

	public int getPrice() {
		return price;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
