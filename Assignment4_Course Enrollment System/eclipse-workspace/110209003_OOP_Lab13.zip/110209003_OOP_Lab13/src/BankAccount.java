
public class BankAccount {
	private int ID;
	private double balance;
	public BankAccount(double balance, int ID) {
		this.ID = ID;
		this.balance = balance;
	}
	public int getID() {
		return ID;
	}
	public void setID(int ID) {
		this.ID = ID;
	}
	public void setBalance(double amount) {
		this.balance = amount;
	}
	public void deposite(double amount) {
		this.balance += amount;
	}
	public void withdraw(double amount) {
		if(this.balance > amount) {
			this.balance -= amount;
		}else{
			System.out.println("Your account does not have enough money.");
		}
	}
	public void monthEnd() {
		
	}
	public double getBalance() {
		return balance;
		
	}
}
