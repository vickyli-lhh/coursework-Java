interface Shape {
	public double getArea();
	public void calcArea();
}
