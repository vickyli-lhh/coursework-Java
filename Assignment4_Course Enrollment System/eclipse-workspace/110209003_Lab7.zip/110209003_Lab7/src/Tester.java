import java.util.ArrayList;
import java.util.Scanner;

public class Tester {

	public static void main(String[] args) {
		ArrayList<String> nameList = new ArrayList<String>();
		String existence, find_index;
		int find_name;
		System.out.print("Create the list with 5 names: ");
		Scanner scanner = new Scanner(System.in);
		int i = 0;
		while (i < 5) {
			String name = scanner.next();
			nameList.add(name);
			i++;
		}
		System.out.print("The name to check existence:");
		existence = scanner.next();
		System.out.print("The name to find index:");
		find_index = scanner.next();
		System.out.print("The index to find name:");
		find_name = scanner.nextInt();
		System.out.println();
		System.out.println("Answer:");
		if (nameList.contains(existence)) {
			System.out.println("1. The list contains " + existence);
		} else {
			System.out.println("1. This ArrayList does not contain " + existence);
		}

		if (nameList.contains(find_index)) {
			System.out.println("2. The index of " + find_index + " is " + nameList.indexOf(find_index));
		} else {
			System.out.println("2. This ArrayList does not contain " + find_index);
		}

		if (find_name < 5 && find_name >= 0) {
			System.out.println("3. Index " + find_name + " is " + nameList.get(find_name));
		} else {
			System.out.println("3.Index out of bound");
		}
		nameList.remove(4);
		if (nameList.isEmpty()) {
			System.out.println("4. The list is empty");
		} else {
			System.out.println("4. The list is not empty");
		}
		System.out.println("5. The size of the list is " + nameList.size());



		
		
		ArrayList<String> myList = new ArrayList<String>();
		String a = new String("HoHoHo"); 
		myList.add(0,a);
		String b = new String("Santa"); 
		myList.add(1,b); 
		System.out.print("Print myList: "); 
		for (String j : myList) {
			System.out.print(j + " ");
		}
		System.out.println();
		int theSize = myList.size(); 
		System.out.println(theSize);
		myList.remove(1); 
		boolean isIn = false; 
		if (myList.contains(b)) {
			isIn = true;
		}
		System.out.println(isIn); 
	}

}
