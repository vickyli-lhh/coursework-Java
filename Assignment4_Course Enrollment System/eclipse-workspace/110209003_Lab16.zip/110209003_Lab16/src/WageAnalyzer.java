public class WageAnalyzer implements Analyzer {
	private String name = "Wage";
	public String getAnalyzerName() {
		return this.name;
	}
	public int measureExpand(Object object) {
		Wage w = (Wage) object;
		return w.getWage() * w.getHour();
	}
	public String getName(Object object) {
		Wage w = (Wage) object;
		return w.getName();
	}
}
