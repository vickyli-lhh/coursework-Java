
interface Analyzer {
	public int measureExpand(Object object);
	public String getName(Object object);
}