public class Wage{
	
	private String name;
	private int wage;
	private int hour;
	
	public Wage(String name, int wage, int hour) {
		this.name = name;
		this.wage = wage;
		this.hour = hour;
	}
	
	public String getName() {		
		return this.name;
	}
	
	public int getWage() {		
		return this.wage;
	}
	
	public int getHour() {
		return this.hour;
	}	
}
